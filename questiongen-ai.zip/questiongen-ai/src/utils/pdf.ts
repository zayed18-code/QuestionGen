import { jsPDF } from 'jspdf';
import type { Question } from '../types';

function sanitizeFilename(topic: string): string {
  return topic
    .replace(/[^a-z0-9\s\-]/gi, '')
    .trim()
    .replace(/\s+/g, '_')
    .slice(0, 40) || 'Topic';
}

export function downloadQuestionPaper(
  topic: string,
  questions: Question[],
  withAnswers = false
): void {
  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 18;
  const contentWidth = pageWidth - margin * 2;
  let y = margin;

  const ensureSpace = (needed: number) => {
    if (y + needed > pageHeight - margin - 10) {
      doc.addPage();
      y = margin;
      addPageNumber(doc);
    }
  };

  const addPageNumber = (d: jsPDF) => {
    const total = d.getNumberOfPages();
    for (let i = 1; i <= total; i++) {
      d.setPage(i);
      d.setFontSize(9);
      d.setTextColor(100);
      d.text(`Page ${i} of ${total}`, pageWidth / 2, pageHeight - 10, { align: 'center' });
    }
  };

  // Header
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(18);
  doc.setTextColor(20);
  doc.text('QUESTION PAPER', pageWidth / 2, y, { align: 'center' });
  y += 10;

  doc.setFontSize(12);
  doc.setFont('helvetica', 'normal');
  doc.text(`Topic: ${topic}`, pageWidth / 2, y, { align: 'center' });
  y += 12;

  // Student fields
  doc.setFontSize(10);
  const fieldGap = 8;
  doc.text('Name: ______________________________', margin, y);
  doc.text('Class: ______________________________', pageWidth / 2 + 5, y);
  y += fieldGap;
  doc.text('Date: _______________________________', margin, y);
  doc.text('Time: _______________________________', pageWidth / 2 + 5, y);
  y += fieldGap;
  doc.text('Marks: ______________________________', margin, y);
  y += 10;

  // Instructions
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.text('Instructions:', margin, y);
  y += 6;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  const instructions = [
    '1. Answer all questions.',
    '2. Read each question carefully.',
    '3. Write your answers clearly.',
  ];
  if (withAnswers) {
    instructions.push('4. Answers are provided after each question for reference.');
  }
  instructions.forEach((line) => {
    doc.text(line, margin, y);
    y += 5;
  });
  y += 6;

  // Divider
  doc.setDrawColor(180);
  doc.line(margin, y, pageWidth - margin, y);
  y += 8;

  // Questions
  questions.forEach((q) => {
    const qText = `${q.number}. ${q.question}`;
    const qLines = doc.splitTextToSize(qText, contentWidth);
    const qHeight = qLines.length * 5.5 + 4;

    let aLines: string[] = [];
    let aHeight = 0;
    if (withAnswers) {
      aLines = doc.splitTextToSize(`Answer: ${q.answer}`, contentWidth - 4);
      aHeight = aLines.length * 5 + 8;
    }

    ensureSpace(qHeight + aHeight + 6);

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(20);
    doc.text(qLines, margin, y);
    y += qLines.length * 5.5 + 3;

    if (withAnswers) {
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(10);
      doc.setTextColor(40);
      doc.setFillColor(245, 245, 245);
      const boxH = aLines.length * 5 + 4;
      doc.rect(margin, y - 3, contentWidth, boxH, 'F');
      doc.text(aLines, margin + 2, y + 2);
      y += boxH + 6;
    } else {
      y += 6;
    }
  });

  addPageNumber(doc);

  const suffix = withAnswers ? '_With_Answers' : '';
  const filename = `Question_Paper_${sanitizeFilename(topic)}${suffix}.pdf`;
  doc.save(filename);
}
