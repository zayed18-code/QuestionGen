import { useState, useEffect, useCallback } from 'react';
import { v4 as uuidv4 } from 'uuid';
import Sidebar from './components/Sidebar';
import ChatView from './components/ChatView';
import HomePrompt from './components/HomePrompt';
import Toast from './components/Toast';
import { loadConversations, addConversation } from './utils/storage';
import type { Conversation, Theme, GenerationResult } from './types';
import { Menu } from 'lucide-react';

function App() {
  const [theme, setTheme] = useState<Theme>(() => {
    const saved = localStorage.getItem('questiongen_theme');
    return (saved as Theme) || 'dark';
  });
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);
  const [difficulty, setDifficulty] = useState('Mixed');
  const [questionType, setQuestionType] = useState('Mixed');

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('questiongen_theme', theme);
  }, [theme]);

  useEffect(() => {
    setConversations(loadConversations());
  }, []);

  const activeConv = conversations.find((c) => c.id === activeId) || null;

  const showToast = useCallback((message: string, type: 'success' | 'error' | 'info' = 'info') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3200);
  }, []);

  const generateQuestions = useCallback(
    async (topic: string) => {
      if (!topic.trim()) {
        showToast('Please enter a topic first.', 'error');
        return;
      }
      setIsGenerating(true);
      try {
        const res = await fetch('/api/generate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            topic: topic.trim(),
            difficulty,
            questionType,
            count: 10,
          }),
        });
        const data = await res.json();
        if (!res.ok) {
          throw new Error(data.error || 'Generation failed');
        }
        const result = data as GenerationResult;
        if (!result.questions || result.questions.length !== 10) {
          throw new Error('Invalid response from server');
        }
        const conv: Conversation = {
          id: uuidv4(),
          topic: result.topic,
          questions: result.questions,
          createdAt: new Date().toISOString(),
        };
        const updated = addConversation(conv);
        setConversations(updated);
        setActiveId(conv.id);
        showToast('Questions generated successfully!', 'success');
      } catch (err: unknown) {
        const msg =
          err instanceof Error
            ? err.message
            : 'Something went wrong while generating the questions. Please try again.';
        showToast(msg, 'error');
      } finally {
        setIsGenerating(false);
      }
    },
    [difficulty, questionType, showToast]
  );

  const handleNewChat = () => {
    setActiveId(null);
    setSidebarOpen(false);
  };

  const handleSelectConversation = (id: string) => {
    setActiveId(id);
    setSidebarOpen(false);
  };

  const handleRegenerate = () => {
    if (activeConv) {
      generateQuestions(activeConv.topic);
    }
  };

  return (
    <div className="flex h-full w-full overflow-hidden" style={{ background: 'var(--bg-primary)' }}>
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/50 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      <Sidebar
        conversations={conversations}
        activeId={activeId}
        onNewChat={handleNewChat}
        onSelect={handleSelectConversation}
        theme={theme}
        onToggleTheme={() => setTheme((t) => (t === 'dark' ? 'light' : 'dark'))}
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
      />

      <main className="flex flex-1 flex-col min-w-0 relative">
        <header
          className="flex items-center gap-3 px-4 py-3 border-b lg:hidden"
          style={{ borderColor: 'var(--border)', background: 'var(--bg-secondary)' }}
        >
          <button
            onClick={() => setSidebarOpen(true)}
            className="p-2 rounded-lg hover:opacity-80 transition"
            style={{ color: 'var(--text-primary)' }}
            aria-label="Open menu"
          >
            <Menu size={22} />
          </button>
          <span className="font-semibold text-lg gradient-text">QuestionGen AI</span>
        </header>

        {activeConv ? (
          <ChatView
            conversation={activeConv}
            isGenerating={isGenerating}
            onRegenerate={handleRegenerate}
            onNewChat={handleNewChat}
            onShowToast={showToast}
          />
        ) : (
          <HomePrompt
            onGenerate={generateQuestions}
            isGenerating={isGenerating}
            difficulty={difficulty}
            setDifficulty={setDifficulty}
            questionType={questionType}
            setQuestionType={setQuestionType}
          />
        )}
      </main>

      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
    </div>
  );
}

export default App;
