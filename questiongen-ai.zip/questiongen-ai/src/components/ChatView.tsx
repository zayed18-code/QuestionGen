import { useState, useRef, useEffect } from 'react';
import {
  Download,
  RefreshCw,
  Copy,
  Plus,
  ChevronDown,
  FileText,
} from 'lucide-react';
import QuestionCard from './QuestionCard';
import LoadingIndicator from './LoadingIndicator';
import { downloadQuestionPaper } from '../utils/pdf';
import type { Conversation } from '../types';

interface Props {
  conversation: Conversation;
  isGenerating: boolean;
  onRegenerate: () => void;
  onNewChat: () => void;
  onShowToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export default function ChatView({
  conversation,
  isGenerating,
  onRegenerate,
  onNewChat,
  onShowToast,
}: Props) {
  const [menuOpen, setMenuOpen] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [conversation, isGenerating]);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const handleCopyAll = () => {
    const text = conversation.questions
      .map((q) => `${q.number}. ${q.question}`)
      .join('\n\n');
    navigator.clipboard.writeText(text).then(() => {
      onShowToast('All questions copied!', 'success');
    });
  };

  const handleCopyOne = (text: string) => {
    navigator.clipboard.writeText(text).then(() => {
      onShowToast('Copied!', 'success');
    });
  };

  const handleDownload = (withAnswers: boolean) => {
    try {
      downloadQuestionPaper(conversation.topic, conversation.questions, withAnswers);
      onShowToast(
        withAnswers ? 'Question paper with answers downloaded.' : 'Question paper downloaded.',
        'success'
      );
      setMenuOpen(false);
    } catch {
      onShowToast('Failed to generate PDF. Please try again.', 'error');
    }
  };

  return (
    <div className="flex-1 flex flex-col min-h-0">
      {/* Messages area */}
      <div className="flex-1 overflow-y-auto px-4 sm:px-6 py-6">
        <div className="max-w-3xl mx-auto space-y-6">
          {/* User message */}
          <div className="flex justify-end animate-fade-in">
            <div
              className="max-w-[85%] rounded-2xl rounded-br-md px-4 py-3 text-sm sm:text-base"
              style={{
                background: 'var(--accent-soft)',
                color: 'var(--text-primary)',
              }}
            >
              Generate questions about {conversation.topic}
            </div>
          </div>

          {/* AI response */}
          {isGenerating ? (
            <LoadingIndicator />
          ) : (
            <div className="space-y-4 animate-fade-in">
              <div
                className="rounded-2xl rounded-bl-md px-4 py-3 text-sm sm:text-base inline-block"
                style={{
                  background: 'var(--bg-card)',
                  border: '1px solid var(--border)',
                  color: 'var(--text-secondary)',
                }}
              >
                Here are 10 questions about <strong style={{ color: 'var(--text-primary)' }}>{conversation.topic}</strong>.
                Click “Show Answer” to reveal each answer.
              </div>

              {conversation.questions.map((q) => (
                <QuestionCard key={q.number} question={q} onCopy={handleCopyOne} />
              ))}
            </div>
          )}
          <div ref={bottomRef} />
        </div>
      </div>

      {/* Toolbar */}
      {!isGenerating && (
        <div
          className="border-t px-4 py-3 sm:px-6"
          style={{ borderColor: 'var(--border)', background: 'var(--bg-secondary)' }}
        >
          <div className="max-w-3xl mx-auto flex flex-wrap items-center gap-2">
            <button
              onClick={onRegenerate}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-sm font-medium transition hover:opacity-80"
              style={{
                background: 'var(--bg-tertiary)',
                color: 'var(--text-secondary)',
                border: '1px solid var(--border)',
              }}
            >
              <RefreshCw size={15} />
              Regenerate
            </button>

            <button
              onClick={() => handleDownload(false)}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-sm font-medium text-white transition hover:opacity-90"
              style={{
                background: 'linear-gradient(135deg, var(--gradient-start), var(--gradient-end))',
              }}
            >
              <Download size={15} />
              Download Question Paper
            </button>

            {/* Secondary menu */}
            <div className="relative" ref={menuRef}>
              <button
                onClick={() => setMenuOpen(!menuOpen)}
                className="flex items-center gap-1 px-3 py-2 rounded-xl text-sm transition hover:opacity-80"
                style={{
                  background: 'var(--bg-tertiary)',
                  color: 'var(--text-secondary)',
                  border: '1px solid var(--border)',
                }}
              >
                More
                <ChevronDown size={14} />
              </button>
              {menuOpen && (
                <div
                  className="absolute bottom-full mb-1 left-0 min-w-[200px] rounded-xl border shadow-lg py-1 z-20 animate-fade-in"
                  style={{
                    background: 'var(--bg-card)',
                    borderColor: 'var(--border)',
                  }}
                >
                  <button
                    onClick={() => handleDownload(true)}
                    className="w-full flex items-center gap-2 px-3 py-2 text-sm text-left hover:opacity-80"
                    style={{ color: 'var(--text-secondary)' }}
                  >
                    <FileText size={15} />
                    Download with Answers
                  </button>
                  <button
                    onClick={handleCopyAll}
                    className="w-full flex items-center gap-2 px-3 py-2 text-sm text-left hover:opacity-80"
                    style={{ color: 'var(--text-secondary)' }}
                  >
                    <Copy size={15} />
                    Copy All Questions
                  </button>
                  <button
                    onClick={onNewChat}
                    className="w-full flex items-center gap-2 px-3 py-2 text-sm text-left hover:opacity-80"
                    style={{ color: 'var(--text-secondary)' }}
                  >
                    <Plus size={15} />
                    Start New Topic
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
