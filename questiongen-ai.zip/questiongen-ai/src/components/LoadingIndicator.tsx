import { useState, useEffect } from 'react';

const MESSAGES = [
  'Thinking...',
  'Creating questions...',
  'Preparing your question paper...',
];

export default function LoadingIndicator() {
  const [idx, setIdx] = useState(0);

  useEffect(() => {
    const t = setInterval(() => {
      setIdx((i) => (i + 1) % MESSAGES.length);
    }, 1800);
    return () => clearInterval(t);
  }, []);

  return (
    <div
      className="rounded-2xl rounded-bl-md px-4 py-4 inline-flex items-center gap-3 animate-fade-in"
      style={{
        background: 'var(--bg-card)',
        border: '1px solid var(--border)',
      }}
    >
      <div className="flex items-center gap-1">
        <span className="loading-dot w-2 h-2 rounded-full inline-block" style={{ background: 'var(--accent)' }} />
        <span className="loading-dot w-2 h-2 rounded-full inline-block" style={{ background: 'var(--accent)' }} />
        <span className="loading-dot w-2 h-2 rounded-full inline-block" style={{ background: 'var(--accent)' }} />
      </div>
      <span className="text-sm" style={{ color: 'var(--text-secondary)' }}>
        {MESSAGES[idx]}
      </span>
    </div>
  );
}
