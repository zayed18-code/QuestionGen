import { Plus, MessageSquare, Moon, Sun, X } from 'lucide-react';
import type { Conversation, Theme } from '../types';

interface Props {
  conversations: Conversation[];
  activeId: string | null;
  onNewChat: () => void;
  onSelect: (id: string) => void;
  theme: Theme;
  onToggleTheme: () => void;
  isOpen: boolean;
  onClose: () => void;
}

export default function Sidebar({
  conversations,
  activeId,
  onNewChat,
  onSelect,
  theme,
  onToggleTheme,
  isOpen,
  onClose,
}: Props) {
  return (
    <aside
      className={`
        fixed lg:static inset-y-0 left-0 z-50
        w-72 flex flex-col
        transition-transform duration-300 ease-out
        ${isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
      `}
      style={{
        background: 'var(--bg-secondary)',
        borderRight: '1px solid var(--border)',
      }}
    >
      <div className="flex items-center justify-between px-4 py-4">
        <div className="flex items-center gap-2">
          <div
            className="w-8 h-8 rounded-xl flex items-center justify-center text-white font-bold text-sm"
            style={{ background: 'linear-gradient(135deg, var(--gradient-start), var(--gradient-end))' }}
          >
            Q
          </div>
          <span className="font-semibold text-base" style={{ color: 'var(--text-primary)' }}>
            QuestionGen AI
          </span>
        </div>
        <button
          onClick={onClose}
          className="lg:hidden p-1.5 rounded-lg hover:opacity-70"
          style={{ color: 'var(--text-secondary)' }}
          aria-label="Close sidebar"
        >
          <X size={18} />
        </button>
      </div>

      <div className="px-3 mb-3">
        <button
          onClick={onNewChat}
          className="w-full flex items-center gap-2 px-3 py-2.5 rounded-xl text-sm font-medium transition-all hover:opacity-90"
          style={{
            background: 'var(--accent-soft)',
            color: 'var(--accent)',
          }}
        >
          <Plus size={18} />
          New Chat
        </button>
      </div>

      <div className="flex-1 overflow-y-auto px-3 pb-4">
        <p
          className="text-xs font-medium uppercase tracking-wider px-2 mb-2"
          style={{ color: 'var(--text-muted)' }}
        >
          Recent Topics
        </p>
        {conversations.length === 0 ? (
          <p className="text-sm px-2 py-4" style={{ color: 'var(--text-muted)' }}>
            No conversations yet
          </p>
        ) : (
          <ul className="space-y-0.5">
            {conversations.map((c) => (
              <li key={c.id}>
                <button
                  onClick={() => onSelect(c.id)}
                  className={`
                    w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-left text-sm transition-colors
                    ${activeId === c.id ? 'font-medium' : ''}
                  `}
                  style={{
                    background: activeId === c.id ? 'var(--accent-soft)' : 'transparent',
                    color: activeId === c.id ? 'var(--accent)' : 'var(--text-secondary)',
                  }}
                >
                  <MessageSquare size={15} className="shrink-0 opacity-70" />
                  <span className="truncate">{c.topic}</span>
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>

      <div className="px-3 py-3 border-t" style={{ borderColor: 'var(--border)' }}>
        <button
          onClick={onToggleTheme}
          className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm transition-colors hover:opacity-80"
          style={{ color: 'var(--text-secondary)' }}
        >
          {theme === 'dark' ? <Sun size={16} /> : <Moon size={16} />}
          {theme === 'dark' ? 'Light mode' : 'Dark mode'}
        </button>
      </div>
    </aside>
  );
}
