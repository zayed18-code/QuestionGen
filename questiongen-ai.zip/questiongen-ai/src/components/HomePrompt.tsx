import { useState, useRef, KeyboardEvent } from 'react';
import { Send, Mic, Paperclip } from 'lucide-react';

interface Props {
  onGenerate: (topic: string) => void;
  isGenerating: boolean;
  difficulty: string;
  setDifficulty: (d: string) => void;
  questionType: string;
  setQuestionType: (t: string) => void;
}

const SUGGESTIONS = [
  'Generate questions about Physics',
  'Generate questions about World History',
  'Generate questions about Biology',
  'Generate questions about Python Programming',
  'Generate questions about Mathematics',
];

export default function HomePrompt({
  onGenerate,
  isGenerating,
  difficulty,
  setDifficulty,
  questionType,
  setQuestionType,
}: Props) {
  const [input, setInput] = useState('');
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const handleSubmit = () => {
    if (!input.trim() || isGenerating) return;
    onGenerate(input.trim());
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  return (
    <div className="flex-1 flex flex-col items-center justify-center px-4 py-8 overflow-y-auto">
      <div className="w-full max-w-2xl mx-auto flex flex-col items-center animate-fade-in">
        {/* Greeting */}
        <h1
          className="text-3xl sm:text-4xl font-semibold text-center mb-2 gradient-text"
          style={{ letterSpacing: '-0.02em' }}
        >
          Create your next question paper
        </h1>
        <p
          className="text-center text-base sm:text-lg mb-10"
          style={{ color: 'var(--text-secondary)' }}
        >
          Enter any topic and generate 10 questions with answers.
        </p>

        {/* Options */}
        <div className="flex flex-wrap gap-3 mb-6 justify-center">
          <div className="flex items-center gap-2">
            <label className="text-xs font-medium" style={{ color: 'var(--text-muted)' }}>
              Difficulty
            </label>
            <select
              value={difficulty}
              onChange={(e) => setDifficulty(e.target.value)}
              className="text-sm rounded-lg px-2.5 py-1.5 border outline-none"
              style={{
                background: 'var(--bg-tertiary)',
                borderColor: 'var(--border)',
                color: 'var(--text-primary)',
              }}
            >
              <option value="Mixed">Mixed</option>
              <option value="Easy">Easy</option>
              <option value="Medium">Medium</option>
              <option value="Hard">Hard</option>
            </select>
          </div>
          <div className="flex items-center gap-2">
            <label className="text-xs font-medium" style={{ color: 'var(--text-muted)' }}>
              Type
            </label>
            <select
              value={questionType}
              onChange={(e) => setQuestionType(e.target.value)}
              className="text-sm rounded-lg px-2.5 py-1.5 border outline-none"
              style={{
                background: 'var(--bg-tertiary)',
                borderColor: 'var(--border)',
                color: 'var(--text-primary)',
              }}
            >
              <option value="Mixed">Mixed</option>
              <option value="Multiple Choice">Multiple Choice</option>
              <option value="Short Answer">Short Answer</option>
              <option value="Long Answer">Long Answer</option>
              <option value="Conceptual">Conceptual</option>
            </select>
          </div>
        </div>

        {/* Prompt box */}
        <div
          className="w-full rounded-2xl soft-glow gradient-border p-1"
          style={{ background: 'var(--bg-secondary)' }}
        >
          <div
            className="rounded-xl p-3 sm:p-4"
            style={{ background: 'var(--bg-secondary)' }}
          >
            <textarea
              ref={textareaRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Enter a topic, subject, or concept..."
              rows={2}
              disabled={isGenerating}
              className="w-full resize-none bg-transparent outline-none text-base leading-relaxed placeholder:opacity-50"
              style={{ color: 'var(--text-primary)' }}
              aria-label="Topic input"
            />
            <div className="flex items-center justify-between mt-2">
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  className="p-2 rounded-lg opacity-50 cursor-not-allowed"
                  style={{ color: 'var(--text-muted)' }}
                  title="Attachment (coming soon)"
                  disabled
                  aria-label="Attach file"
                >
                  <Paperclip size={18} />
                </button>
                <button
                  type="button"
                  className="p-2 rounded-lg opacity-50 cursor-not-allowed"
                  style={{ color: 'var(--text-muted)' }}
                  title="Voice input (coming soon)"
                  disabled
                  aria-label="Voice input"
                >
                  <Mic size={18} />
                </button>
              </div>
              <button
                onClick={handleSubmit}
                disabled={!input.trim() || isGenerating}
                className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium text-white transition-all disabled:opacity-40 disabled:cursor-not-allowed hover:opacity-90"
                style={{
                  background: 'linear-gradient(135deg, var(--gradient-start), var(--gradient-end))',
                }}
                aria-label="Generate questions"
              >
                {isGenerating ? (
                  <span className="flex items-center gap-1.5">
                    <span className="loading-dot w-1.5 h-1.5 rounded-full bg-white inline-block" />
                    <span className="loading-dot w-1.5 h-1.5 rounded-full bg-white inline-block" />
                    <span className="loading-dot w-1.5 h-1.5 rounded-full bg-white inline-block" />
                  </span>
                ) : (
                  <>
                    <Send size={16} />
                    Generate
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Suggestions */}
        <div className="flex flex-wrap gap-2 mt-6 justify-center">
          {SUGGESTIONS.map((s) => (
            <button
              key={s}
              onClick={() => {
                setInput(s.replace('Generate questions about ', ''));
                textareaRef.current?.focus();
              }}
              className="text-xs sm:text-sm px-3 py-1.5 rounded-full border transition-colors hover:opacity-80"
              style={{
                borderColor: 'var(--border)',
                color: 'var(--text-secondary)',
                background: 'var(--bg-tertiary)',
              }}
            >
              {s}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
