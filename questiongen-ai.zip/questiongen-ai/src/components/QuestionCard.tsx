import { useState } from 'react';
import { ChevronDown, ChevronUp, Copy, Check } from 'lucide-react';
import type { Question } from '../types';

interface Props {
  question: Question;
  onCopy: (text: string) => void;
}

const difficultyColor: Record<string, string> = {
  Easy: 'var(--success)',
  Medium: 'var(--warning)',
  Hard: 'var(--danger)',
};

export default function QuestionCard({ question, onCopy }: Props) {
  const [expanded, setExpanded] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    onCopy(`${question.number}. ${question.question}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <div
      className="rounded-2xl border p-4 sm:p-5 animate-fade-in"
      style={{
        background: 'var(--bg-card)',
        borderColor: 'var(--border)',
      }}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex-1 min-w-0">
          <div className="flex flex-wrap items-center gap-2 mb-2">
            <span
              className="text-xs font-semibold px-2 py-0.5 rounded-md"
              style={{
                background: 'var(--accent-soft)',
                color: 'var(--accent)',
              }}
            >
              Q{question.number}
            </span>
            <span
              className="text-xs font-medium px-2 py-0.5 rounded-md"
              style={{
                background: `${difficultyColor[question.difficulty] || 'var(--text-muted)'}22`,
                color: difficultyColor[question.difficulty] || 'var(--text-muted)',
              }}
            >
              {question.difficulty}
            </span>
            <span
              className="text-xs px-2 py-0.5 rounded-md"
              style={{
                background: 'var(--bg-tertiary)',
                color: 'var(--text-secondary)',
              }}
            >
              {question.type}
            </span>
          </div>
          <p
            className="text-sm sm:text-base leading-relaxed"
            style={{ color: 'var(--text-primary)' }}
          >
            {question.question}
          </p>
        </div>
        <button
          onClick={handleCopy}
          className="p-1.5 rounded-lg shrink-0 hover:opacity-70 transition"
          style={{ color: 'var(--text-muted)' }}
          aria-label="Copy question"
          title="Copy question"
        >
          {copied ? <Check size={16} style={{ color: 'var(--success)' }} /> : <Copy size={16} />}
        </button>
      </div>

      {/* Answer toggle */}
      <div className="mt-3 pt-3 border-t" style={{ borderColor: 'var(--border)' }}>
        <button
          onClick={() => setExpanded(!expanded)}
          className="flex items-center gap-1.5 text-sm font-medium transition hover:opacity-80"
          style={{ color: 'var(--accent)' }}
        >
          {expanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
          {expanded ? 'Hide Answer' : 'Show Answer'}
        </button>
        {expanded && (
          <div
            className="mt-2 p-3 rounded-xl text-sm leading-relaxed animate-fade-in"
            style={{
              background: 'var(--bg-tertiary)',
              color: 'var(--text-secondary)',
            }}
          >
            <span className="font-medium" style={{ color: 'var(--text-primary)' }}>
              Answer:{' '}
            </span>
            {question.answer}
          </div>
        )}
      </div>
    </div>
  );
}
