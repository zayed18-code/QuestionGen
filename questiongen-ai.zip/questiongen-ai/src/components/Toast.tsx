import { X } from 'lucide-react';

interface Props {
  message: string;
  type: 'success' | 'error' | 'info';
  onClose: () => void;
}

const colors = {
  success: 'var(--success)',
  error: 'var(--danger)',
  info: 'var(--accent)',
};

export default function Toast({ message, type, onClose }: Props) {
  return (
    <div
      className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 flex items-center gap-3 px-4 py-3 rounded-xl shadow-lg animate-fade-in max-w-[90vw]"
      style={{
        background: 'var(--bg-card)',
        border: `1px solid ${colors[type]}`,
        color: 'var(--text-primary)',
      }}
      role="alert"
    >
      <div
        className="w-2 h-2 rounded-full shrink-0"
        style={{ background: colors[type] }}
      />
      <span className="text-sm">{message}</span>
      <button
        onClick={onClose}
        className="p-0.5 rounded hover:opacity-70 ml-1"
        style={{ color: 'var(--text-muted)' }}
        aria-label="Dismiss"
      >
        <X size={14} />
      </button>
    </div>
  );
}
