export type Difficulty = 'Easy' | 'Medium' | 'Hard';
export type QuestionType =
  | 'Multiple Choice'
  | 'Short Answer'
  | 'Conceptual'
  | 'Definition'
  | 'Application'
  | 'Reasoning'
  | 'Compare and Contrast'
  | 'Long Answer';

export interface Question {
  number: number;
  question: string;
  answer: string;
  difficulty: Difficulty;
  type: string;
}

export interface GenerationResult {
  topic: string;
  questions: Question[];
}

export interface Conversation {
  id: string;
  topic: string;
  questions: Question[];
  createdAt: string;
}

export type Theme = 'dark' | 'light';
