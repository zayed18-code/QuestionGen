/**
 * High-quality offline question generator.
 * Produces educational, varied questions with accurate answers for common topics
 * and sensible general questions for any other topic.
 */

const TOPIC_BANKS = {
  photosynthesis: [
    { q: 'What is photosynthesis?', a: 'Photosynthesis is the process by which green plants, algae and some bacteria convert light energy into chemical energy, producing glucose and oxygen from carbon dioxide and water.', d: 'Easy', t: 'Definition' },
    { q: 'What are the main raw materials required for photosynthesis?', a: 'Carbon dioxide (CO₂), water (H₂O) and sunlight (light energy). Chlorophyll is also essential as the light-absorbing pigment.', d: 'Easy', t: 'Short Answer' },
    { q: 'Write the balanced chemical equation for photosynthesis.', a: '6CO₂ + 6H₂O + light energy → C₆H₁₂O₆ + 6O₂', d: 'Medium', t: 'Short Answer' },
    { q: 'Where does the light-dependent reaction of photosynthesis take place?', a: 'In the thylakoid membranes of the chloroplasts.', d: 'Medium', t: 'Conceptual' },
    { q: 'Explain the role of chlorophyll in photosynthesis.', a: 'Chlorophyll absorbs light energy (mainly in the blue and red wavelengths) and initiates the electron transport chain that powers the conversion of light energy into chemical energy.', d: 'Medium', t: 'Conceptual' },
    { q: 'What is the difference between the light-dependent and light-independent reactions?', a: 'Light-dependent reactions occur in the thylakoids, require light, produce ATP and NADPH and release O₂. Light-independent reactions (Calvin cycle) occur in the stroma, do not require light directly, and use ATP and NADPH to fix CO₂ into glucose.', d: 'Hard', t: 'Compare and Contrast' },
    { q: 'Why are the leaves of most plants green?', a: 'Because chlorophyll reflects green wavelengths of light while absorbing red and blue wavelengths for photosynthesis.', d: 'Easy', t: 'Reasoning' },
    { q: 'How does temperature affect the rate of photosynthesis?', a: 'Photosynthesis increases with temperature up to an optimum (usually 25–35 °C for many plants) because enzyme activity rises; beyond the optimum, enzymes denature and the rate falls.', d: 'Hard', t: 'Application' },
    { q: 'What is the Calvin cycle and what does it produce?', a: 'The Calvin cycle is the light-independent set of reactions that uses ATP and NADPH to fix atmospheric CO₂ into organic molecules, ultimately producing glucose (and other carbohydrates).', d: 'Hard', t: 'Conceptual' },
    { q: 'Name two factors that limit the rate of photosynthesis in natural conditions.', a: 'Light intensity, carbon dioxide concentration and temperature are the three classic limiting factors. Any two of these are acceptable.', d: 'Medium', t: 'Short Answer' },
  ],
  'newton': [
    { q: "State Newton's First Law of Motion.", a: "An object remains at rest or in uniform motion in a straight line unless acted upon by a net external force. (Law of Inertia)", d: 'Easy', t: 'Definition' },
    { q: "State Newton's Second Law of Motion.", a: 'The acceleration of an object is directly proportional to the net force acting on it and inversely proportional to its mass: F = ma.', d: 'Easy', t: 'Definition' },
    { q: "State Newton's Third Law of Motion.", a: 'For every action there is an equal and opposite reaction. Forces always occur in pairs.', d: 'Easy', t: 'Definition' },
    { q: 'What is inertia? Give an everyday example.', a: 'Inertia is the tendency of an object to resist changes in its state of motion. Example: passengers lurch forward when a bus suddenly brakes.', d: 'Medium', t: 'Application' },
    { q: 'A force of 20 N acts on a 4 kg mass. What is its acceleration?', a: 'a = F/m = 20 N / 4 kg = 5 m/s².', d: 'Medium', t: 'Application' },
    { q: 'Explain why a rocket moves forward when fuel is ejected backward.', a: "By Newton's Third Law: the rocket pushes exhaust gases backward (action) and the gases push the rocket forward with equal force (reaction).", d: 'Medium', t: 'Reasoning' },
    { q: 'Differentiate between mass and weight.', a: 'Mass is the amount of matter in an object (scalar, constant). Weight is the gravitational force acting on that mass (vector, W = mg) and varies with location.', d: 'Hard', t: 'Compare and Contrast' },
    { q: 'What is the relationship between force, mass and acceleration?', a: 'Net force equals mass times acceleration (F_net = ma). This is the mathematical statement of Newton’s Second Law.', d: 'Medium', t: 'Conceptual' },
    { q: 'Why do objects of different masses fall at the same rate in a vacuum?', a: 'Gravitational acceleration g is independent of mass. In a vacuum there is no air resistance, so all objects accelerate at g regardless of mass.', d: 'Hard', t: 'Reasoning' },
    { q: 'A 2 kg object is accelerated at 3 m/s². Calculate the net force.', a: 'F = ma = 2 kg × 3 m/s² = 6 N.', d: 'Easy', t: 'Application' },
  ],
  python: [
    { q: 'What is Python?', a: 'Python is a high-level, interpreted, general-purpose programming language known for its readability and extensive standard library.', d: 'Easy', t: 'Definition' },
    { q: 'How do you create a list in Python? Give an example.', a: 'Use square brackets: my_list = [1, 2, 3, "hello"]. Lists are ordered, mutable collections.', d: 'Easy', t: 'Short Answer' },
    { q: 'What is the difference between a list and a tuple?', a: 'Lists are mutable (can be changed after creation); tuples are immutable. Lists use [], tuples use ().', d: 'Medium', t: 'Compare and Contrast' },
    { q: 'Explain what a Python dictionary is and how to access a value.', a: 'A dictionary is an unordered collection of key-value pairs. Access a value with dict[key] or dict.get(key).', d: 'Medium', t: 'Conceptual' },
    { q: 'What does the following code print? print(type(3.14))', a: "It prints <class 'float'>.", d: 'Easy', t: 'Application' },
    { q: 'How do you define a function in Python?', a: 'Use the def keyword: def function_name(parameters): followed by an indented body.', d: 'Easy', t: 'Short Answer' },
    { q: 'What is list comprehension? Give a simple example.', a: 'A concise way to create lists. Example: squares = [x**2 for x in range(5)] produces [0, 1, 4, 9, 16].', d: 'Hard', t: 'Conceptual' },
    { q: 'Explain the difference between == and is in Python.', a: '== checks value equality; is checks object identity (whether two references point to the same object in memory).', d: 'Hard', t: 'Compare and Contrast' },
    { q: 'What is a Python module and how do you import one?', a: 'A module is a file containing Python definitions and statements. Import with import module_name or from module_name import item.', d: 'Medium', t: 'Conceptual' },
    { q: 'How do you handle exceptions in Python?', a: 'Use try / except blocks. Optionally include else and finally. Example: try: ... except ValueError as e: ...', d: 'Medium', t: 'Application' },
  ],
  biology: [
    { q: 'What is a cell?', a: 'The basic structural and functional unit of all living organisms.', d: 'Easy', t: 'Definition' },
    { q: 'Name the three domains of life.', a: 'Bacteria, Archaea and Eukarya.', d: 'Easy', t: 'Short Answer' },
    { q: 'What is the function of the mitochondria?', a: 'Mitochondria are the powerhouses of the cell; they generate ATP through cellular respiration.', d: 'Easy', t: 'Conceptual' },
    { q: 'Differentiate between prokaryotic and eukaryotic cells.', a: 'Prokaryotic cells lack a membrane-bound nucleus and organelles; eukaryotic cells have a true nucleus and membrane-bound organelles.', d: 'Medium', t: 'Compare and Contrast' },
    { q: 'What is DNA and what is its primary function?', a: 'Deoxyribonucleic acid is the hereditary material that stores genetic information and directs protein synthesis.', d: 'Medium', t: 'Definition' },
    { q: 'Explain the process of mitosis in brief.', a: 'Mitosis is cell division that produces two genetically identical daughter cells. Stages: prophase, metaphase, anaphase, telophase (followed by cytokinesis).', d: 'Hard', t: 'Conceptual' },
    { q: 'What is natural selection?', a: 'The process by which organisms better adapted to their environment tend to survive and produce more offspring, driving evolution.', d: 'Medium', t: 'Definition' },
    { q: 'Name the four bases of DNA.', a: 'Adenine (A), Thymine (T), Guanine (G) and Cytosine (C).', d: 'Easy', t: 'Short Answer' },
    { q: 'How does a vaccine work?', a: 'A vaccine introduces a harmless form of a pathogen (or its antigens) so the immune system can produce memory cells and antibodies without causing disease.', d: 'Hard', t: 'Application' },
    { q: 'What is the role of enzymes in biological systems?', a: 'Enzymes are biological catalysts that speed up chemical reactions by lowering activation energy, without being consumed.', d: 'Medium', t: 'Conceptual' },
  ],
  history: [
    { q: 'What was the Industrial Revolution?', a: 'A period of major industrialization and innovation that began in Britain in the late 18th century and spread worldwide, transforming economies from agrarian to industrial.', d: 'Easy', t: 'Definition' },
    { q: 'Who was the first President of the United States?', a: 'George Washington.', d: 'Easy', t: 'Short Answer' },
    { q: 'What caused World War I to begin in 1914?', a: 'The assassination of Archduke Franz Ferdinand of Austria-Hungary in Sarajevo, combined with a complex system of alliances, militarism, imperialism and nationalism.', d: 'Medium', t: 'Reasoning' },
    { q: 'Explain the significance of the Magna Carta.', a: 'Signed in 1215, it limited the power of the English king and established the principle that everyone, including the monarch, is subject to the law.', d: 'Medium', t: 'Conceptual' },
    { q: 'What was the Cold War?', a: 'A period of geopolitical tension (roughly 1947–1991) between the United States and the Soviet Union and their respective allies, characterized by ideological conflict, arms race and proxy wars without direct large-scale fighting between the superpowers.', d: 'Medium', t: 'Definition' },
    { q: 'Compare the causes of the French Revolution and the American Revolution.', a: 'Both involved Enlightenment ideas and opposition to perceived tyranny. The American Revolution focused on colonial independence from Britain; the French Revolution sought radical internal social and political reform against absolute monarchy and inequality.', d: 'Hard', t: 'Compare and Contrast' },
    { q: 'What was the significance of the fall of the Berlin Wall?', a: 'In 1989 it symbolized the end of the Cold War division of Europe and paved the way for German reunification and the collapse of communist regimes in Eastern Europe.', d: 'Medium', t: 'Conceptual' },
    { q: 'Who wrote the Declaration of Independence?', a: 'Primarily Thomas Jefferson, with input from the Committee of Five.', d: 'Easy', t: 'Short Answer' },
    { q: 'What was the Renaissance?', a: 'A cultural, artistic and intellectual revival that began in Italy in the 14th century and spread across Europe, marking the transition from the Middle Ages to modernity.', d: 'Easy', t: 'Definition' },
    { q: 'Explain the concept of imperialism in the 19th century.', a: 'The policy of extending a nation’s power and influence through colonization, military force or other means; European powers carved up large parts of Africa and Asia.', d: 'Hard', t: 'Conceptual' },
  ],
  mathematics: [
    { q: 'What is the Pythagorean theorem?', a: 'In a right-angled triangle, the square of the hypotenuse equals the sum of the squares of the other two sides: a² + b² = c².', d: 'Easy', t: 'Definition' },
    { q: 'Solve for x: 2x + 5 = 15.', a: '2x = 10 → x = 5.', d: 'Easy', t: 'Application' },
    { q: 'What is the derivative of x² with respect to x?', a: '2x.', d: 'Medium', t: 'Short Answer' },
    { q: 'Explain the difference between a permutation and a combination.', a: 'Permutation: order matters. Combination: order does not matter. P(n,r) = n!/(n-r)!, C(n,r) = n!/(r!(n-r)!).', d: 'Hard', t: 'Compare and Contrast' },
    { q: 'What is the area of a circle with radius r?', a: 'A = πr².', d: 'Easy', t: 'Short Answer' },
    { q: 'State the quadratic formula.', a: 'For ax² + bx + c = 0, x = [-b ± √(b² − 4ac)] / (2a).', d: 'Medium', t: 'Definition' },
    { q: 'What is the integral of 2x dx?', a: 'x² + C (where C is the constant of integration).', d: 'Medium', t: 'Application' },
    { q: 'Define a prime number and give three examples.', a: 'A natural number greater than 1 that has no positive divisors other than 1 and itself. Examples: 2, 3, 5, 7, 11.', d: 'Easy', t: 'Definition' },
    { q: 'What is the slope of the line y = 3x − 4?', a: 'The slope is 3.', d: 'Easy', t: 'Short Answer' },
    { q: 'Explain the concept of a limit in calculus.', a: 'A limit describes the value that a function approaches as the input approaches some value. It is foundational to derivatives and integrals.', d: 'Hard', t: 'Conceptual' },
  ],
};

function normalizeKey(topic) {
  const t = topic.toLowerCase();
  if (t.includes('photo') || t.includes('plant')) return 'photosynthesis';
  if (t.includes('newton') || t.includes('force') || t.includes('motion') || t.includes('inertia')) return 'newton';
  if (t.includes('python') || t.includes('programming') || t.includes('code')) return 'python';
  if (t.includes('bio') || t.includes('cell') || t.includes('dna') || t.includes('gene')) return 'biology';
  if (t.includes('history') || t.includes('war') || t.includes('revolution') || t.includes('ancient')) return 'history';
  if (t.includes('math') || t.includes('algebra') || t.includes('calculus') || t.includes('geometry')) return 'mathematics';
  return null;
}

function generateGeneric(topic, difficultyPref, typePref) {
  const difficulties = ['Easy', 'Medium', 'Hard'];
  const types = ['Definition', 'Short Answer', 'Conceptual', 'Application', 'Reasoning', 'Compare and Contrast'];
  const templates = [
    { q: `What is ${topic}?`, a: `${topic} is a key concept in its field. A precise definition depends on the specific context, but it generally refers to the fundamental principles, processes or ideas associated with the subject.`, d: 'Easy', t: 'Definition' },
    { q: `List three important aspects or components of ${topic}.`, a: `Key aspects typically include foundational principles, practical applications, and historical or theoretical development of ${topic}. Specific details should be studied from authoritative sources on the subject.`, d: 'Easy', t: 'Short Answer' },
    { q: `Explain the significance of ${topic} in modern education or practice.`, a: `${topic} plays an important role because it underpins many related concepts and real-world applications. Understanding it enables deeper insight into the broader domain.`, d: 'Medium', t: 'Conceptual' },
    { q: `How would you apply knowledge of ${topic} to solve a real-world problem?`, a: `Application involves identifying the relevant principles of ${topic}, gathering necessary data, applying the appropriate methods or formulas, and evaluating the results against expected outcomes.`, d: 'Hard', t: 'Application' },
    { q: `What are the main challenges or limitations associated with ${topic}?`, a: `Challenges often include complexity of concepts, measurement difficulties, contextual variability, and the need for continuous updates as knowledge advances.`, d: 'Medium', t: 'Reasoning' },
    { q: `Compare and contrast two major approaches or theories related to ${topic}.`, a: `Different approaches to ${topic} may emphasize different assumptions, methods or goals. Comparing them highlights strengths, weaknesses and suitable use-cases for each.`, d: 'Hard', t: 'Compare and Contrast' },
    { q: `Define a key term commonly used when discussing ${topic}.`, a: `Key terminology in ${topic} helps precise communication. Students should learn the standard definitions used by experts in the field.`, d: 'Easy', t: 'Definition' },
    { q: `Describe a step-by-step process involved in ${topic}.`, a: `Processes related to ${topic} typically follow a logical sequence of stages. Understanding each stage and its purpose is essential for mastery.`, d: 'Medium', t: 'Conceptual' },
    { q: `Why is it important for students to study ${topic}?`, a: `Studying ${topic} builds critical thinking, provides foundational knowledge for advanced topics, and equips learners with skills applicable beyond the classroom.`, d: 'Medium', t: 'Reasoning' },
    { q: `Give an example that illustrates a core principle of ${topic}.`, a: `Concrete examples help solidify understanding. A well-chosen example demonstrates how the abstract principles of ${topic} appear in practice.`, d: 'Hard', t: 'Application' },
  ];

  return templates.map((item, i) => {
    let d = item.d;
    let t = item.t;
    if (difficultyPref && difficultyPref !== 'Mixed') d = difficultyPref;
    if (typePref && typePref !== 'Mixed') t = typePref;
    return {
      number: i + 1,
      question: item.q,
      answer: item.a,
      difficulty: d,
      type: t,
    };
  });
}

export function generateMockQuestions(topic, difficulty = 'Mixed', questionType = 'Mixed') {
  const key = normalizeKey(topic);
  let questions;
  if (key && TOPIC_BANKS[key]) {
    questions = TOPIC_BANKS[key].map((item, i) => ({
      number: i + 1,
      question: item.q,
      answer: item.a,
      difficulty: difficulty !== 'Mixed' ? difficulty : item.d,
      type: questionType !== 'Mixed' ? questionType : item.t,
    }));
  } else {
    questions = generateGeneric(topic, difficulty, questionType);
  }
  return { topic, questions };
}
