/**
 * Zero-dependency HTTP server for QuestionGen AI
 * Uses only Node.js built-ins + the mock generator
 */
import http from 'http';
import { generateMockQuestions } from './mockGenerator.js';
import { URL } from 'url';

const PORT = process.env.PORT || 3001;

const rateMap = new Map();
const RATE_LIMIT = 30;
const WINDOW_MS = 60 * 1000;

function rateLimit(ip) {
  const now = Date.now();
  let entry = rateMap.get(ip);
  if (!entry || now - entry.start > WINDOW_MS) {
    entry = { start: now, count: 0 };
    rateMap.set(ip, entry);
  }
  entry.count += 1;
  return entry.count <= RATE_LIMIT;
}

function sendJSON(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Length': Buffer.byteLength(body),
  });
  res.end(body);
}

const server = http.createServer(async (req, res) => {
  // CORS preflight
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    });
    return res.end();
  }

  const ip = req.socket.remoteAddress || 'unknown';

  if (req.method === 'GET' && req.url === '/api/health') {
    return sendJSON(res, 200, { status: 'ok', mode: 'standalone-mock' });
  }

  if (req.method === 'POST' && req.url === '/api/generate') {
    if (!rateLimit(ip)) {
      return sendJSON(res, 429, { error: 'Too many requests. Please wait a moment.' });
    }

    let body = '';
    req.on('data', (chunk) => { body += chunk; if (body.length > 1e6) req.destroy(); });
    req.on('end', () => {
      try {
        const data = JSON.parse(body || '{}');
        const topic = (data.topic || '').trim().slice(0, 200);
        if (!topic) {
          return sendJSON(res, 400, { error: 'Please enter a topic first.' });
        }
        const difficulty = data.difficulty || 'Mixed';
        const questionType = data.questionType || 'Mixed';
        const result = generateMockQuestions(topic, difficulty, questionType);
        sendJSON(res, 200, result);
      } catch (err) {
        console.error(err);
        sendJSON(res, 500, { error: 'Something went wrong while generating the questions. Please try again.' });
      }
    });
    return;
  }

  sendJSON(res, 404, { error: 'Not found' });
});

server.listen(PORT, () => {
  console.log(`QuestionGen AI (standalone) server on http://localhost:${PORT}`);
  console.log('Using high-quality offline mock generator.');
});
