import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import OpenAI from 'openai';
import { generateMockQuestions } from './mockGenerator.js';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors());
app.use(express.json({ limit: '1mb' }));

// Simple in-memory rate limit (per IP)
const rateMap = new Map();
const RATE_LIMIT = 20; // requests per window
const WINDOW_MS = 60 * 1000;

function rateLimit(req, res, next) {
  const ip = req.ip || req.connection.remoteAddress || 'unknown';
  const now = Date.now();
  let entry = rateMap.get(ip);
  if (!entry || now - entry.start > WINDOW_MS) {
    entry = { start: now, count: 0 };
    rateMap.set(ip, entry);
  }
  entry.count += 1;
  if (entry.count > RATE_LIMIT) {
    return res.status(429).json({ error: 'Too many requests. Please wait a moment.' });
  }
  next();
}

const SYSTEM_PROMPT = `You are an expert educational question-paper generator.
Given a topic, generate exactly 10 high-quality questions about that topic.
Requirements:
1. Generate exactly 10 questions.
2. Questions must be directly related to the requested topic.
3. Do not repeat questions.
4. Cover different concepts within the topic.
5. Use a mixture of Easy, Medium, and Hard difficulty (prefer ~3 Easy, ~4 Medium, ~3 Hard).
6. Provide accurate answers for every question.
7. Keep questions clear and educational.
8. Avoid ambiguous questions.
9. Do not invent facts.
10. Return valid JSON only.
11. Do not include Markdown outside the JSON.
12. Each question must contain: number, question, answer, difficulty, type.

Allowed difficulty values: "Easy", "Medium", "Hard"
Allowed type values: "Multiple Choice", "Short Answer", "Conceptual", "Definition", "Application", "Reasoning", "Compare and Contrast", "Long Answer"

JSON format:
{
  "topic": "...",
  "questions": [
    {
      "number": 1,
      "question": "...",
      "answer": "...",
      "difficulty": "Easy",
      "type": "Short Answer"
    }
  ]
}`;

function validateAndNormalize(data, topic) {
  if (!data || typeof data !== 'object') return null;
  let questions = Array.isArray(data.questions) ? data.questions : [];
  // Pad or trim to exactly 10
  if (questions.length > 10) questions = questions.slice(0, 10);
  while (questions.length < 10) {
    const n = questions.length + 1;
    questions.push({
      number: n,
      question: `Explain a key concept related to ${topic} (question ${n}).`,
      answer: `This is a placeholder answer for concept ${n} of ${topic}. Please regenerate for better results.`,
      difficulty: ['Easy', 'Medium', 'Hard'][n % 3],
      type: 'Short Answer',
    });
  }
  return {
    topic: data.topic || topic,
    questions: questions.map((q, i) => ({
      number: i + 1,
      question: String(q.question || `Question ${i + 1}`).trim(),
      answer: String(q.answer || 'Answer not provided.').trim(),
      difficulty: ['Easy', 'Medium', 'Hard'].includes(q.difficulty) ? q.difficulty : 'Medium',
      type: String(q.type || 'Short Answer').trim(),
    })),
  };
}

app.post('/api/generate', rateLimit, async (req, res) => {
  try {
    const { topic, difficulty = 'Mixed', questionType = 'Mixed', count = 10 } = req.body || {};
    if (!topic || typeof topic !== 'string' || !topic.trim()) {
      return res.status(400).json({ error: 'Please enter a topic first.' });
    }
    const cleanTopic = topic.trim().slice(0, 200);

    const apiKey = process.env.AI_API_KEY || process.env.OPENAI_API_KEY;
    let result = null;

    if (apiKey) {
      try {
        const openai = new OpenAI({
          apiKey,
          baseURL: process.env.AI_BASE_URL || undefined, // e.g. for Grok or other OpenAI-compatible
        });
        const model = process.env.AI_MODEL || 'gpt-4o-mini';

        let userPrompt = `Generate exactly 10 educational questions about: "${cleanTopic}".`;
        if (difficulty && difficulty !== 'Mixed') {
          userPrompt += ` Prefer difficulty: ${difficulty}.`;
        }
        if (questionType && questionType !== 'Mixed') {
          userPrompt += ` Prefer question type: ${questionType}.`;
        }
        userPrompt += ' Return only valid JSON matching the required schema.';

        const completion = await openai.chat.completions.create({
          model,
          messages: [
            { role: 'system', content: SYSTEM_PROMPT },
            { role: 'user', content: userPrompt },
          ],
          temperature: 0.7,
          max_tokens: 4000,
          response_format: { type: 'json_object' },
        });

        const content = completion.choices?.[0]?.message?.content || '';
        const parsed = JSON.parse(content);
        result = validateAndNormalize(parsed, cleanTopic);
      } catch (aiErr) {
        console.error('AI API error:', aiErr.message);
        // Fall through to mock
      }
    }

    if (!result) {
      // High-quality mock generator (works offline / without key)
      result = generateMockQuestions(cleanTopic, difficulty, questionType);
    }

    res.json(result);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Something went wrong while generating the questions. Please try again.' });
  }
});

app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', hasKey: !!(process.env.AI_API_KEY || process.env.OPENAI_API_KEY) });
});

app.listen(PORT, () => {
  console.log(`QuestionGen AI server running on http://localhost:${PORT}`);
  if (!(process.env.AI_API_KEY || process.env.OPENAI_API_KEY)) {
    console.log('No AI_API_KEY set — using high-quality mock generator.');
  }
});
